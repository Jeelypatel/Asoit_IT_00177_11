<?php
if(isset($_GET["submit"]))
{
    if(isset($_GET["no1"]) && isset($_GET["no2"])&& isset($_GET["no2"]))
    {
        $no1 = $_GET["no1"];
        $no2 = $_GET["no2"];
        $no3 = $_GET["no3"];
        $res = $no1 + $no2 + $no3;
    }
}
?>
<html>
<form action="#" method="get">
<input type="text" id="fname" name="no1"><br><br>
<input type="text" id="fname" name="no2"><br><br>
<input type="text" id="fname" name="no3"><br><br>
<input type="submit" name="submit" value="Submit"><br><br>
<input type="text" id="fname" name="result" value=" <?php if(isset($res)){echo $res;} ?>"><br><br>
</form>
</html>